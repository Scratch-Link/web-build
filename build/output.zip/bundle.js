(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){

},{}],2:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Background = Background;
function Background(router) {
  var _require = require("../lib/Framework.mjs"),
    Page = _require.Page;
  var page = new Page("Background");
  var wave1 = page.image("wave1.svg");
  var wave2 = page.image("wave2.svg");
  page.html("\n        <div id=\"background\">\n            <div class=\"scroll\">\n                <div class=\"m-scroll\">\n                    <span><img src=\"".concat(wave1, "\"></span>\n                    <span><img src=\"").concat(wave2, "\"></span>\n                    <span><img src=\"").concat(wave1, "\"></span>\n                    <span><img src=\"").concat(wave2, "\"></span>\n                    <span><img src=\"").concat(wave1, "\"></span>\n                    <span><img src=\"").concat(wave2, "\"></span>\n                    <span><img src=\"").concat(wave1, "\"></span>\n                    <span><img src=\"").concat(wave2, "\"></span>\n                    <span><img src=\"").concat(wave1, "\"></span>\n                    <span><img src=\"").concat(wave2, "\"></span>\n                    <span><img src=\"").concat(wave1, "\"></span>\n                    <span><img src=\"").concat(wave2, "\"></span>\n                </div>\n            </div>\n        </div>\n    "));
  page.css("\n        #background {\n            z-index:-1;\n            background-color: #001220;\n            top:0;\n            left: 0;\n            width: 100%;\n            height: 100%;\n            position:fixed;\n        }\n        .scroll {\n            position: relative;\n            width: 1200%;\n            overflow: hidden;\n            z-index: 1;\n            margin: 0;\n            padding: 0;\n            bottom: 0;\n        }\n        .m-scroll {\n            bottom: 0;\n            overflow: hidden;\n            position: fixed;\n            white-space: nowrap;\n            animation: scrollText 10s infinite linear;\n            margin: 0;\n            font-size: 0;\n            display: flex;\n            justify-content: space-between;\n            align-items: end;\n            width: fit-content;\n        }\n    \n        span {\n            bottom: 0;\n            display: inline-block;\n            margin: 0;\n            padding: 0;\n            color: white;\n        }\n        @keyframes scrollText {\n            from {\n                transform: translateX(0%);\n            }\n    \n            to {\n                transform: translateX(-50%);\n            }\n        }\n    ");
  page.render();
}

},{"../lib/Framework.mjs":5}],3:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Fonts = Fonts;
function Fonts(router) {
  var _require = require("../lib/Framework.mjs"),
    Page = _require.Page;
  var page = new Page("Fonts");
  page.html("\n    <link rel=\"preconnect\" href=\"https://fonts.googleapis.com\">\n    <link rel=\"preconnect\" href=\"https://fonts.gstatic.com\" crossorigin>\n    <link href=\"https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&display=swap\" rel=\"stylesheet\">\n    ");
  page.css('');
  page.render();
}

},{"../lib/Framework.mjs":5}],4:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Navbar = Navbar;
function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function Navbar(router) {
  var _require = require("../lib/Framework.mjs"),
    Page = _require.Page;
  var page = new Page("Navbar");
  page.html("\n    <div id=\"navbar\">\n        <a id=\"button-home\">\n            <div id=\"title\">  \n                    <svg width=\"92\" height=\"92\" viewBox=\"0 0 92 92\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" id=\"logo\">\n                        <circle cx=\"46\" cy=\"46\" r=\"46\" fill=\"white\" />\n                        <path d=\"M45.5 6L62 46L45.5 86L29 46L45.5 6Z\" fill=\"url(#paint0_linear_868_2)\" />\n                        <defs>\n                            <linearGradient id=\"paint0_linear_868_2\" x1=\"26.525\" y1=\"12.1333\" x2=\"52.0414\" y2=\"85.1675\"\n                                gradientUnits=\"userSpaceOnUse\">\n                                <stop stop-color=\"#00FFF0\" />\n                                <stop offset=\"1\" stop-color=\"#089EFF\" />\n                            </linearGradient>\n                        </defs>\n                    </svg>\n                </a>\n                <a id=\"main\">   \n                    <h1>Scratch <span class=\"color-2\">Link</span></h1>\n\n            </div>\n        </a>\n        <div id=\"blank\"></div>\n        <div id=\"links\">\n            <a class=\"link\" id=\"package\">Packages</a>\n            <a class=\"link\" id=\"project\">Projects</a>\n            <a class=\"link\" id=\"api\">Api</a>\n            <a class=\"link\" id=\"status\">Status</a>\n            <a class=\"link\" id=\"login\">Login</a>\n        </div>\n    </div>\n    ");
  page.css("\n        #button-home {\n            z-index:100;\n            width: fit-content;\n            height: fit-content;\n        }\n        h1 {\n            font-family: 'Montserrat', sans-serif;\n            color: #FFFFFF;\n            text-align: center;\n            font-size: 49px;\n            font-style: normal;\n            font-weight: 600;\n        }\n\n        .color-2 {\n            color: #089EFF;\n        }\n        #navbar {\n            position:fixed;\n            top: 1%;\n            left: 0;\n            width: 100%;\n            height: 10%;\n            display: flex;\n            justify-content: space-around;\n            align-items: center;\n            flex-direction: row;\n            z-index:10;\n        }\n\n        #title {\n            width: 430px;\n            height: 100%;\n            display: flex;\n            justify-content: space-around;\n            align-items: center;\n            flex-direction: row;\n        }\n\n        #blank {\n            width: 25%;\n            height: 100%;\n        }\n\n        #links {\n            width: 45%;\n            height: 100%;\n            display: flex;\n            justify-content: space-around;\n            align-items: center;\n            flex-direction: row;\n        }\n\n        .link {\n            z-index:100;\n            color: #FFF;\n            text-align: center;\n            font-family: Montserrat;\n            font-size: 26px;\n            font-style: normal;\n            font-weight: 600;\n            line-height: normal;\n        }\n        a {\n            cursor: pointer;\n            text-decoration: none;\n        }\n    ");
  function on_render() {
    var buttons = page.document.getElementsByClassName("link");
    var buttonPressed = function buttonPressed(e) {
      router.navigateTo("/" + e.target.id);
    };
    var _iterator = _createForOfIteratorHelper(buttons),
      _step;
    try {
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        var button = _step.value;
        button.addEventListener("click", buttonPressed);
      }
    } catch (err) {
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
    document.getElementById("logo").onclick = function () {
      router.navigateTo("/");
    };
  }
  page.on_render(on_render);
  page.render();
}

},{"../lib/Framework.mjs":5}],5:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Router = exports.Page = void 0;
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor); } }
function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : String(i); }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
var fs = require('fs');
var pages = {};
var CanNavigate = true;
function SwitchCanNavigate(newdata) {
  CanNavigate = newdata;
}
var Page = exports.Page = /*#__PURE__*/function () {
  function Page(route) {
    _classCallCheck(this, Page);
    this.route = route;
    this.document;
    pages[this.route.toLowerCase()] = this;
  }
  _createClass(Page, [{
    key: "html",
    value: function html(code) {
      this.html = code;
    }
  }, {
    key: "css",
    value: function css(code) {
      this.css = code;
    }
  }, {
    key: "delete_animation",
    value: function delete_animation(code) {
      this.delete_anim = code;
    }
  }, {
    key: "spawn_animation",
    value: function spawn_animation(code) {
      this.create_anim = code;
    }
  }, {
    key: "image",
    value: function image(path) {
      return "./assets/" + path;
    }
  }, {
    key: "spawn",
    value: function spawn() {
      var newStyle = document.createElement("style");
      newStyle.innerHTML = this.create_anim;
      this.document.appendChild(newStyle);
      var _iterator = _createForOfIteratorHelper(this.document.children),
        _step;
      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var child = _step.value;
          if (child.tagName.toLowerCase() == 'div') {
            child.style.animation = 'spawn 1s';
          }
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
    }
  }, {
    key: "delete",
    value: function _delete() {
      var _this = this;
      var newStyle = document.createElement("style");
      newStyle.innerHTML = this.delete_anim;
      this.document.appendChild(newStyle);
      var _iterator2 = _createForOfIteratorHelper(this.document.children),
        _step2;
      try {
        var _loop = function _loop() {
            var child = _step2.value;
            if (child.tagName.toLowerCase() == 'div') {
              child.style.animation = 'delete 1s';
              var self = _this;
              SwitchCanNavigate(false);
              _handler = function handler() {
                child.removeEventListener("animationend", _handler, false);
                self.document.remove();
                SwitchCanNavigate(true);
              };
              child.addEventListener("animationend", _handler, false);
            }
          },
          _handler;
        for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
          _loop();
        }
      } catch (err) {
        _iterator2.e(err);
      } finally {
        _iterator2.f();
      }
    }
  }, {
    key: "clear",
    value: function clear(except) {
      var elems = document.body.children;
      if (Array.isArray(except) == false) {
        except = [];
      }
      except.push("noscript");
      except.push("script");
      var _iterator3 = _createForOfIteratorHelper(elems),
        _step3;
      try {
        for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
          var elem = _step3.value;
          if (except.includes(elem.tagName.toLowerCase()) == false) {
            if (document.body.getElementsByTagName(elem) != null) {
              if (elem.tagName.toLowerCase() in pages) {
                try {
                  pages[elem.tagName.toLowerCase()]["delete"]();
                } catch (_unused) {
                  elem.remove();
                }
              } else {
                elem.remove();
              }
            }
          }
        }
      } catch (err) {
        _iterator3.e(err);
      } finally {
        _iterator3.f();
      }
    }
  }, {
    key: "on_render",
    value: function on_render(func) {
      this.on = func;
    }
  }, {
    key: "render",
    value: function render() {
      if (document.getElementsByTagName(this.route.toLowerCase()).length == 0) {
        var newDiv = document.createElement(this.route.toLowerCase());
        newDiv.innerHTML = this.html;
        document.body.appendChild(newDiv);
        var newStyle = document.createElement("style");
        newStyle.innerHTML = this.css;
        newDiv.appendChild(newStyle);
        this.document = newDiv;
        this.spawn();
        if (typeof this.on == "function") {
          this.on();
        }
      }
    }
  }]);
  return Page;
}();
var Router = exports.Router = /*#__PURE__*/function () {
  function Router() {
    _classCallCheck(this, Router);
    this.routes = {};
    this.errors = {};
  }
  _createClass(Router, [{
    key: "registerRoute",
    value: function registerRoute(endpoint, filePath) {
      this.routes[endpoint] = filePath;
    }
  }, {
    key: "registerError",
    value: function registerError(error, filePath) {
      this.errors[error] = filePath;
    }
  }, {
    key: "navigateError",
    value: function navigateError(code) {
      if (CanNavigate == false) {
        return "";
      }
      var functionpage = this.errors[code];
      if (functionpage) {
        try {
          if (typeof functionpage === 'function') {
            functionpage(this);
          } else {
            for (var i in functionpage) {
              functionpage[i](this);
            }
          }
        } catch (error) {
          console.error("Error loading module for code ".concat(code, ":"), error);
        }
      } else {
        console.error("No handler registered for error: ".concat(code));
      }
    }
  }, {
    key: "navigateTo",
    value: function navigateTo(endpoint) {
      if (CanNavigate == false) {
        return "";
      }
      var functionpage = this.routes[endpoint];
      if (functionpage) {
        try {
          if (typeof functionpage === 'function') {
            functionpage(this);
          } else {
            for (var i in functionpage) {
              functionpage[i](this);
            }
          }
        } catch (error) {
          console.error("Error loading module for endpoint ".concat(endpoint, ":"), error);
        }
      } else {
        this.navigateError(404);
        console.error("No handler registered for endpoint: ".concat(endpoint));
      }
    }
  }, {
    key: "start",
    value: function start() {
      var currentEndpoint = window.location.pathname;
      this.navigateTo(currentEndpoint);
    }
  }]);
  return Router;
}();

},{"fs":1}],6:[function(require,module,exports){
"use strict";

var _require = require("./lib/Framework.mjs"),
  Router = _require.Router;
var _require2 = require("./pages/landing.mjs"),
  Landing = _require2.Landing;
var _require3 = require("./pages/login.mjs"),
  Login = _require3.Login;
var _require4 = require("./pages/register.mjs"),
  Register = _require4.Register;
var _require5 = require("./pages/errors.mjs"),
  NotFound = _require5.NotFound;
var router = new Router();
router.registerRoute("/", [Landing]);
router.registerRoute("/login", [Login]);
router.registerRoute("/register", [Register]);
router.registerError(404, [NotFound]);
router.start();

},{"./lib/Framework.mjs":5,"./pages/errors.mjs":7,"./pages/landing.mjs":8,"./pages/login.mjs":9,"./pages/register.mjs":10}],7:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.NotFound = NotFound;
function NotFound(router) {
  var _require = require("../lib/Framework.mjs"),
    Page = _require.Page;
  var _require2 = require("../elements/fonts.mjs"),
    Fonts = _require2.Fonts;
  var _require3 = require("../elements/background.mjs"),
    Background = _require3.Background;
  var _require4 = require("../elements/navbar.mjs"),
    Navbar = _require4.Navbar;
  var page = new Page("NotFound");
  page.clear(["background", "navbar", "fonts"]);
  Fonts(router);
  Background(router);
  Navbar(router);
  page.html("<div id=\"center-contain\">\n        <div id=\"error-code\"> 404 </div>\n        <h3> I don\u2019t know who or what went wrong, but someone or something sure went ! </h3>\n        <a class=\"button\" id=\"main-menu\">Main Menu</a>\n    </div>");
  page.css("\n\n    #center-contain {\n        z-index:0;\n        width: 100%;\n        height: 100%;\n        position:absolute;\n        top:0;\n        left:0;\n        display:flex;\n        justify-content:center;\n        align-items:center;\n        flex-direction: column;\n    }\n\n    #error-code {\n        text-align: center;\n        font-family: Montserrat;\n        font-size: 300px;\n        font-style: normal;\n        font-weight: 600;\n        line-height: normal;\n        background: linear-gradient(149deg, rgba(0, 255, 240, 1) 0%, rgba(8, 158, 255, 1) 100%);\n        -webkit-background-clip: text;\n        color: transparent;\n    }\n\n    h3 {\n        font-family: 'Montserrat', sans-serif;\n        color: #FFFFFF;\n        text-align: center;\n    }\n\n    .button {\n        color: #FFF;\n        text-align: center;\n        font-family: Montserrat;\n        font-size: 26px;\n        font-style: normal;\n        font-weight: 600;\n        line-height: normal;\n    }\n\n    #main-menu {\n        width: 220px;\n        height: 50px;\n        border-radius: 128px;\n        background: #089EFF;\n        display: flex;\n        justify-content: center;\n        align-items: center;\n    }\n\n    a {\n        cursor: pointer;\n        text-decoration: none;\n    }\n    ");
  page.delete_animation("\n    @keyframes delete {\n        0% {\n          opacity: 1;\n          transform: translateY(0%);\n        }\n        100% {\n          opacity: 0;\n          transform: translateY(10%); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  page.spawn_animation("\n    @keyframes spawn {\n        0% {\n          opacity: 0;\n          transform: translateY(-10%);\n        }\n        100% {\n          opacity: 1;\n          transform: translateY(0); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  function on_render() {
    document.getElementById("main-menu").onclick = function () {
      router.navigateTo("/");
    };
  }
  page.on_render(on_render);
  page.render();
}

},{"../elements/background.mjs":2,"../elements/fonts.mjs":3,"../elements/navbar.mjs":4,"../lib/Framework.mjs":5}],8:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Landing = Landing;
function Landing(router) {
  var _require = require("../lib/Framework.mjs"),
    Page = _require.Page;
  var _require2 = require("../elements/fonts.mjs"),
    Fonts = _require2.Fonts;
  var _require3 = require("../elements/background.mjs"),
    Background = _require3.Background;
  var _require4 = require("../elements/navbar.mjs"),
    Navbar = _require4.Navbar;
  var page = new Page("Landing");
  page.clear(["background", "navbar", "fonts"]);
  Fonts(router);
  Background(router);
  Navbar(router);
  page.html("\n        <div id=\"text-container\">\n            <h1>Connect your <span class=\"color-1\">project</span> to a new <span class=\"color-2\">dimension</span><br>Simply\n                and reliably.</h1>\n            <h3>Grab the sprite, register your project and access limitless possibilities.</h3>\n            <div id=\"button-container\">\n                <a id=\"register\" class=\"button\">Register</a>\n                <a class=\"button\" id=\"learn\">Learn More</a>\n            </div>\n        </div>\n    ");
  page.css("\n        body,\n        html {\n            margin: 0;\n            padding: 0;\n            overflow: hidden;\n        }\n  \n        #text-container {\n            top: 15%;\n            left: 0;\n            position: absolute;\n            width: 100%;\n            height: 55%;\n            display: flex;\n            justify-content: center;\n            align-items: center;\n            flex-direction: column;\n        }\n    \n        h1 {\n            font-family: 'Montserrat', sans-serif;\n            color: #FFFFFF;\n            text-align: center;\n            font-size: 49px;\n            font-style: normal;\n            font-weight: 600;\n        }\n    \n        h3 {\n            font-family: 'Montserrat', sans-serif;\n            color: #FFFFFF;\n            text-align: center;\n        }\n    \n        .color-1 {\n            color: #00FFF0;\n        }\n    \n        .color-2 {\n            color: #089EFF;\n        }\n    \n        #button-container {\n            width: 30%;\n            margin-top: 3%;\n            height: 10%;\n            display: flex;\n            justify-content: space-around;\n            align-items: center;\n            flex-direction: row;\n        }\n    \n        .button {\n            color: #FFF;\n            text-align: center;\n            font-family: Montserrat;\n            font-size: 26px;\n            font-style: normal;\n            font-weight: 600;\n            line-height: normal;\n        }\n    \n        #register {\n            width: 220px;\n            height: 50px;\n            border-radius: 128px;\n            background: #089EFF;\n            display: flex;\n            justify-content: center;\n            align-items: center;\n        }\n    \n        a {\n            cursor: pointer;\n            text-decoration: none;\n        }\n    ");
  page.delete_animation("\n    @keyframes delete {\n        0% {\n          opacity: 1;\n          transform: translateY(0%);\n        }\n        100% {\n          opacity: 0;\n          transform: translateY(10%); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  page.spawn_animation("\n    @keyframes spawn {\n        0% {\n          opacity: 0;\n          transform: translateY(-10%);\n        }\n        100% {\n          opacity: 1;\n          transform: translateY(0); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  function on_render() {
    document.getElementById("register").onclick = function () {
      router.navigateTo("/register");
    };
    document.getElementById("learn").onclick = function () {
      router.navigateTo("/learn");
    };
  }
  page.on_render(on_render);
  page.render();
}

},{"../elements/background.mjs":2,"../elements/fonts.mjs":3,"../elements/navbar.mjs":4,"../lib/Framework.mjs":5}],9:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Login = Login;
function Login(router) {
  var _require = require("../lib/Framework.mjs"),
    Page = _require.Page;
  var _require2 = require("../elements/fonts.mjs"),
    Fonts = _require2.Fonts;
  var _require3 = require("../elements/background.mjs"),
    Background = _require3.Background;
  var _require4 = require("../elements/navbar.mjs"),
    Navbar = _require4.Navbar;
  var page = new Page("Login");
  var auth_logo = page.image("scratch_auth_logo.svg");
  page.clear(["background", "navbar", "fonts"]);
  Fonts(router);
  Background(router);
  Navbar(router);
  page.html("\n    <div id=\"center-contain\">\n        <svg width=\"92\" height=\"92\" viewBox=\"0 0 92 92\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" id=\"logo\">\n            <circle cx=\"46\" cy=\"46\" r=\"46\" fill=\"white\" />\n            <path d=\"M45.5 6L62 46L45.5 86L29 46L45.5 6Z\" fill=\"url(#paint0_linear_868_2)\" />\n            <defs>\n                <linearGradient id=\"paint0_linear_868_2\" x1=\"26.525\" y1=\"12.1333\" x2=\"52.0414\" y2=\"85.1675\"\n                    gradientUnits=\"userSpaceOnUse\">\n                    <stop stop-color=\"#00FFF0\" />\n                    <stop offset=\"1\" stop-color=\"#089EFF\" />\n                </linearGradient>\n            </defs>\n        </svg>\n        <h1 id=\"title-login\" >Login to Scratch <span class=\"color-2\">Link</span></h1>\n        <div class=\"input-container\">\n            <div class=\"input-label\">Username</div>\n            <input id=\"username\"></input>\n        </div>\n        <div class=\"input-container\" id=\"margin-down\">\n            <div class=\"input-label\">Password</div>\n            <input id=\"password\" type=\"password\"></input>\n        </div>\n        <div class=\"button\"><p>Login</p></div>\n        <div class=\"button auth\"><img src=\"".concat(auth_logo, "\" /><p>Login with Scratch Auth</p></div>\n    </div>\n    "));
  page.css("\n    #margin-down {\n        margin-bottom: 3%;\n    }\n    #title-login {\n        margin-bottom:3%;\n        font-size: 33px\n    }\n    #center-contain {\n        z-index:0;\n        width: 100%;\n        height: 100%;\n        position:absolute;\n        top:0;\n        left:0;\n        display:flex;\n        justify-content:center;\n        align-items:center;\n        flex-direction: column;\n    }\n        \n    .color-1 {\n        color: #00FFF0;\n    }\n\n    .color-2 {\n        color: #089EFF;\n    }\n    h1 {\n        font-family: 'Montserrat', sans-serif;\n        color: #FFFFFF;\n        text-align: center;\n        font-size: 49px;\n        font-style: normal;\n        font-weight: 600;\n    }\n\n    h3 {\n        font-family: 'Montserrat', sans-serif;\n        color: #FFFFFF;\n        text-align: center;\n    }\n    .input-container {\n        width:30%;\n        height:5%;\n        margin-bottom:2%;\n    }\n    .input-label{\n        width: fit-content;\n        position:relative;\n        text-align:start;\n        font-family: 'Montserrat', sans-serif;\n        color: #FFFFFF;\n    }\n    input {\n        background-color: #000B14;\n        border-radius:8px;\n        height:100%;\n        width:100%;\n        appearance: none;\n        border: none;\n        outline: solid #002038;\n        font-family: 'Montserrat', sans-serif;\n        color: #FFFFFF;\n        text-align:center;\n        \n    }\n    .button {\n        background-color:#089EFF;\n        width:30%;\n        height:5%;\n        margin-bottom:2%;\n        border-radius:8px;\n        font-family: 'Montserrat', sans-serif;\n        color: #FFFFFF;\n        text-align:center;\n        display:flex;\n        justify-content:center;\n        align-items:center;\n    }\n    .button p {\n        color: #FFF;\n        text-align: center;\n        font-family: Montserrat;\n        font-size: 26px;\n        font-style: normal;\n        font-weight: 600;\n        line-height: normal;\n    }\n    .auth {\n        background-color:#000000\n    }\n    .auth img{\n        margin-right:5%;\n        filter: invert(76%) sepia(39%) saturate(3603%) hue-rotate(343deg) brightness(100%) contrast(102%);\n    }\n    ");
  page.delete_animation("\n    @keyframes delete {\n        0% {\n          opacity: 1;\n          transform: translateY(0%);\n        }\n        100% {\n          opacity: 0;\n          transform: translateY(10%); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  page.spawn_animation("\n    @keyframes spawn {\n        0% {\n          opacity: 0;\n          transform: translateY(-10%);\n        }\n        100% {\n          opacity: 1;\n          transform: translateY(0); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  page.render();
}

},{"../elements/background.mjs":2,"../elements/fonts.mjs":3,"../elements/navbar.mjs":4,"../lib/Framework.mjs":5}],10:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Register = Register;
function Register(router) {
  var _require = require("../lib/Framework.mjs"),
    Page = _require.Page;
  var _require2 = require("../elements/fonts.mjs"),
    Fonts = _require2.Fonts;
  var _require3 = require("../elements/background.mjs"),
    Background = _require3.Background;
  var _require4 = require("../elements/navbar.mjs"),
    Navbar = _require4.Navbar;
  var page = new Page("Register");
  var auth_logo = page.image("scratch_auth_logo.svg");
  page.clear(["background", "navbar", "fonts"]);
  Fonts(router);
  Background(router);
  Navbar(router);
  page.html("\n    <div id=\"center-contain\">\n        <svg width=\"92\" height=\"92\" viewBox=\"0 0 92 92\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" id=\"logo\">\n            <circle cx=\"46\" cy=\"46\" r=\"46\" fill=\"white\" />\n            <path d=\"M45.5 6L62 46L45.5 86L29 46L45.5 6Z\" fill=\"url(#paint0_linear_868_2)\" />\n            <defs>\n                <linearGradient id=\"paint0_linear_868_2\" x1=\"26.525\" y1=\"12.1333\" x2=\"52.0414\" y2=\"85.1675\"\n                    gradientUnits=\"userSpaceOnUse\">\n                    <stop stop-color=\"#00FFF0\" />\n                    <stop offset=\"1\" stop-color=\"#089EFF\" />\n                </linearGradient>\n            </defs>\n        </svg>\n        <h1 id=\"title-login\" >Register to Scratch <span class=\"color-2\">Link</span></h1>\n        <div class=\"input-container\">\n            <div class=\"input-label\">Username</div>\n            <input id=\"username\"></input>\n        </div>\n        <div class=\"input-container\" id=\"margin-down\">\n            <div class=\"input-label\">Password</div>\n            <input id=\"password\" type=\"password\"></input>\n        </div>\n        <div class=\"button\"><p>Register</p></div>\n        <div class=\"button auth\"><img src=\"".concat(auth_logo, "\" /><p>Register with Scratch Auth</p></div>\n    </div>\n    "));
  page.css("\n    #margin-down {\n        margin-bottom: 3%;\n    }\n    #title-login {\n        margin-bottom:3%;\n        font-size: 33px\n    }\n    #center-contain {\n        z-index:0;\n        width: 100%;\n        height: 100%;\n        position:absolute;\n        top:0;\n        left:0;\n        display:flex;\n        justify-content:center;\n        align-items:center;\n        flex-direction: column;\n    }\n        \n    .color-1 {\n        color: #00FFF0;\n    }\n\n    .color-2 {\n        color: #089EFF;\n    }\n    h1 {\n        font-family: 'Montserrat', sans-serif;\n        color: #FFFFFF;\n        text-align: center;\n        font-size: 49px;\n        font-style: normal;\n        font-weight: 600;\n    }\n\n    h3 {\n        font-family: 'Montserrat', sans-serif;\n        color: #FFFFFF;\n        text-align: center;\n    }\n    .input-container {\n        width:30%;\n        height:5%;\n        margin-bottom:2%;\n    }\n    .input-label{\n        width: fit-content;\n        position:relative;\n        text-align:start;\n        font-family: 'Montserrat', sans-serif;\n        color: #FFFFFF;\n    }\n    input {\n        background-color: #000B14;\n        border-radius:8px;\n        height:100%;\n        width:100%;\n        appearance: none;\n        border: none;\n        outline: solid #002038;\n        font-family: 'Montserrat', sans-serif;\n        color: #FFFFFF;\n        text-align:center;\n        \n    }\n    .button {\n        background-color:#089EFF;\n        width:30%;\n        height:5%;\n        margin-bottom:2%;\n        border-radius:8px;\n        font-family: 'Montserrat', sans-serif;\n        color: #FFFFFF;\n        text-align:center;\n        display:flex;\n        justify-content:center;\n        align-items:center;\n    }\n    .button p {\n        color: #FFF;\n        text-align: center;\n        font-family: Montserrat;\n        font-size: 26px;\n        font-style: normal;\n        font-weight: 600;\n        line-height: normal;\n    }\n    .auth {\n        background-color:#000000\n    }\n    .auth img{\n        margin-right:5%;\n        filter: invert(76%) sepia(39%) saturate(3603%) hue-rotate(343deg) brightness(100%) contrast(102%);\n    }\n    ");
  page.delete_animation("\n    @keyframes delete {\n        0% {\n          opacity: 1;\n          transform: translateY(0%);\n        }\n        100% {\n          opacity: 0;\n          transform: translateY(10%); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  page.spawn_animation("\n    @keyframes spawn {\n        0% {\n          opacity: 0;\n          transform: translateY(-10%);\n        }\n        100% {\n          opacity: 1;\n          transform: translateY(0); /* Adjust the distance you want to move on the y-axis */\n        }\n      }\n    ");
  page.render();
}

},{"../elements/background.mjs":2,"../elements/fonts.mjs":3,"../elements/navbar.mjs":4,"../lib/Framework.mjs":5}]},{},[6]);
